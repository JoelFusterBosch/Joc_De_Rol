/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package altres;

/**
 *
 * @author Joel
 */
public class Poder {
    //Objectes
    private String nom;
    private int BonusAtac;
    private int BonusDefensa;
    //toString per a Equip
    @Override
    public String toString() {
        return nom +" (BA:"+ BonusAtac+", BD:"+ BonusDefensa+" )";
    }
    //Constructor de Poder
    public Poder(String nom, int bonusAtac, int BonusDefensa) {
        this.nom = nom;
        this.BonusAtac = bonusAtac;
        this.BonusDefensa = BonusDefensa;
    }
    //Getters i setters
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getBonusAtac() {
        return BonusAtac;
    }

    public void setBonusAtac(int bonusAtac) {
        this.BonusAtac = bonusAtac;
    }

    public int getBonusDefensa() {
        return BonusDefensa;
    }

    public void setBonusDefensa(int BonusDefensa) {
        this.BonusDefensa = BonusDefensa;
    }
}