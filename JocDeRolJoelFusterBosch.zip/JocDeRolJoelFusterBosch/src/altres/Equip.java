/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package altres;
import java.util.ArrayList;
import jocderoljoelfusterbosch.personatges.Jugador;

/**
 *
 * @author Joel
 */
public class Equip{
    //Objextes
    private String nom;
    private ArrayList <Jugador> jugador=new ArrayList();
    //Getters i setters
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }
    public Equip(String nom) {
        this.nom = nom;
    }
    public void posa(Jugador j){
        //Posa un jugador a l'equip
        if(jugador.contains(j)){
            jugador.add(j);
        } else {  
            System.out.println("Eixe jugador no existeix");
        }
    }
    public void lleva(Jugador j){
        //Lleva el jugador del equip
        jugador.remove(j);
        j=null;
    }  
//toString de equip
    @Override
    public String toString() {
        super.toString();
        return "Equip "+ nom +":" ;
    }
    
}
