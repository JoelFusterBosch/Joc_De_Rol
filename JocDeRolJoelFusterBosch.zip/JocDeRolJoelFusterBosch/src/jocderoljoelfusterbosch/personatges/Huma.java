/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jocderoljoelfusterbosch.personatges;

/**
 *
 * @author Joel
 */
public class Huma extends Jugador{
    
    public Huma(String nom, int pa, int pd, int vides) {
        super(nom, pa, pd, vides);
        int vidaMax=100;
        if (super.getVides()>100){
            super.setVides(vidaMax);
        }
    }
    
}
