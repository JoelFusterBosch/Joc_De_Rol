/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jocderoljoelfusterbosch.personatges;

/**
 *
 * @author Joel
 */
public class Alien extends Jugador {
    //Constructor de Alien
    public Alien(String nom, int pa, int pd, int vides) {
        super(nom, pa, pd, vides);
    }
    //Mètode ataca per a alien
    @Override
    public void ataca(Jugador j) {
        int punta=super.getPa()+3;
        int puntd=super.getPd()-3;
        if (super.getVides()>20) {
            super.setPa(punta);
            super.setPd(puntd);
            if(super.getPd()<0){
                puntd=0;
                super.setPd(puntd);
            }
        }
        super.ataca(j);        
    } 
}
   

