/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jocderoljoelfusterbosch.personatges;

/**
 *
 * @author Joel
 */
public class Guerrer extends Huma {
    //Constructor de Guerrer
    public Guerrer(String nom, int pa, int pd, int vides) {
        super(nom, pa, pd, vides);

    }
    //Mètode ataca per a guerrer
    @Override
    public void ataca(Jugador j) {
        
        int jresta = super.getPa() - super.getPd();
        int vidallev=super.getVides()-jresta;
        if (jresta < 5) {
            System.out.println("No ha rebut mal");
        }else{
            super.setVides(vidallev);
        }
        super.ataca(j);
    }

}
