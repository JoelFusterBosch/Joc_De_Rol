/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jocderoljoelfusterbosch.personatges;

import altres.Equip;
import altres.Poder;
import java.util.ArrayList;
import java.util.Objects;

/**
 *
 * @author Joel
 */
public class Jugador {
    //Objectes
    private String nom;
    private int pa;
    private int pd;
    private int vides;
    private Equip equip;
    private ArrayList<Poder> poder = new ArrayList();
    static int videsInicials = 200;
    // Getters i setters
    public static int getVidesInicials() {
        return videsInicials;
    }

    public Equip getEquip() {
        return equip;
    }

    public void setEquip(Equip equip) {
        this.equip = equip;
        //Possar jugadors en equips
        if (equip == null) {
            this.equip.lleva(this);
        } else {
            this.equip.posa(this);
        }
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getPa() {
        return pa;
    }

    protected void setPa(int pa) {
        this.pa = pa;
    }

    public int getPd() {
        return pd;
    }

    protected void setPd(int pd) {
        this.pd = pd;
    }

    public int getVides() {
        return vides;
    }

    public ArrayList<Poder> getPoder() {
        return poder;
    }

    public void setPoder(ArrayList<Poder> poder) {
        this.poder = poder;
    }

    protected void setVides(int vides) {
        this.vides = vides;
    }

    public void ataca(Jugador j) {
        //Abans del atac
        System.out.println("ABANS DE L'ATAC");
        System.out.println("    Atacant:" + this.toString());
        System.out.println("    Atacat:" + j.toString());
        System.out.println("ATAC");
        //Calculs del jugador atacant
        int thisresta;
        int bonusAtac = 0;
        int bonusDefensa = 0;
        for (Poder poder1 : this.poder) {
            bonusAtac = poder1.getBonusAtac();
            bonusDefensa = poder1.getBonusDefensa();
        }
        //Controlador d'errors per a no isquen negatius
        if (this.getPa() > this.getPd()) {

            thisresta = (this.getPa() + bonusAtac) - (this.getPd() + bonusDefensa);
        } else {
            thisresta = (this.getPd()+bonusDefensa) - (this.getPa() + bonusAtac);
        }
        int thisvidaRes = this.getVides() - thisresta;
        if (this.vides - thisresta < 0) {
            this.setVides(0);
        }
        //Hora de l'atac
        System.out.print("    " + this.getNom() + " es colpejat amb " + this.getPa() + " punts i es defen amb " + this.getPd() + ". Vides:" + this.getVides() + " - " + thisresta + " =" + thisvidaRes);
        this.esColpejatAmb(this.getPa());
        System.out.println("");
        //Calculs del jugador atacat
        int jresta;
        int bonusAtac2 = 0;
        int bonusDefensa2 = 0;
        for (Poder poder1 : j.poder) {
            bonusAtac2 = poder1.getBonusAtac();
            bonusDefensa2 = poder1.getBonusDefensa();
        }
        //Controlador d'errors per a no isquen negatius
        if (j.getPa() > j.getPd()) {
            jresta = (j.getPa()+bonusAtac2) - (j.getPd()+bonusDefensa2);
        } else {
            jresta = j.getPd() - j.getPa();
        }
        int jvidaRes = this.getVides() - jresta;
        System.out.print("    " + j.getNom() + " es colpejat amb " + j.getPa() + " punts i es defen amb " + j.getPd() + ". Vides:" + j.getVides() + " - " + jresta + " =" + jvidaRes);
        j.esColpejatAmb(j.getPa());
        //Després de colpejar
        System.out.println("");
        System.out.println("DESPRES DE L'ATAC");
        System.out.println("    Atacant:" + this.toString());
        System.out.println("    Atacat:" + j.toString());   
    }

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Jugador other = (Jugador) obj;
        return Objects.equals(this.nom, other.nom);
    }

    protected void esColpejatAmb(int pa) {
        //Metode per a colpejar al jugador i es cridat per el mètode ataca
        int pvallevar = pa - this.pd;
        if (pvallevar > 0) {
            int pv = this.vides - (pvallevar);
            if (pv <= 0) {
                System.out.println("Mort");
            }
        }
    }

    void posa(Poder poder) {
        //Posar un jugador
        this.poder.add(poder);
    }

    void lleva(Poder poder) {
        //Llevar un jugador
        this.poder.remove(poder);
    }
    //Constructor de Jugador
    public Jugador(String nom, int pa, int pd, int vides) {
        this.nom = nom;
        this.pa = pa;
        this.pd = pd;
        this.vides = vides;
    }
    //Mètode toString
    @Override
    //toString fet, queda posar els bonus d'atac i de defensa pels poders
    public String toString() {
        String poder = "";
        for (int i = 0; i < getPoder().size(); i++) {
            poder += getPoder().indexOf(i);
        }
        return getNom() + " [" + getEquip() + "] " + "( " + Jugador.class.getSimpleName() + ", PA:" + pa + ", PD:" + pd + ", vides=" + vides + ")\n" + poder;
    }
}
