/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jocderoljoelfusterbosch.inici;

import Teclat.Teclat;
import altres.Equip;
import altres.Poder;
import java.util.ArrayList;
import jocderoljoelfusterbosch.personatges.Alien;
import jocderoljoelfusterbosch.personatges.Guerrer;
import jocderoljoelfusterbosch.personatges.Huma;
import jocderoljoelfusterbosch.personatges.Jugador;

/**
 *
 * @author Joel
 */
public class Jugadors {

    static ArrayList<Jugador> llista = new ArrayList();

    static void menu() {
        boolean eixir_bucle = false;
        while (!eixir_bucle) {
            int opcio = Teclat.lligOpcio("JUGADORS", "Crear", "Consultar", "Eliminar", "Asignar a equip", "Llevar d'equip", "Asignar poder");
            switch (opcio) {
                case 1:
                    crear();
                    break;
                case 2:
                    consultar();
                    break;
                case 3:
                    eliminar();
                    break;
                case 4:
                    assignarEquip();
                    break;
                case 5:
                    llevarEquip();
                    break;
                case 6:
                    assignarPoder();
                    break;
                case 0:
                    eixir_bucle = true;
            }
        }
    }
    private static void crear() {
        //Pregunta el tipo de jugador que vol ser
        char jugador = Teclat.lligChar("Quin tipus de jugador vols H/G/A?");
        //Control d'errors per a no afegir un tipus de jugador no existent
        if (jugador != 'H' && jugador != 'A' && jugador != 'G') {
            System.out.println("Jugador no creat a causa de no agarrar la raça correcta");
            return;
        }
        //Preguntar per el nom, punts d'atac i de defensa
        String nom = Teclat.lligString("Quin nom vols?");
        int pa = Teclat.lligInt("Quants punts de atac vols?", 1, 100);
        int pd = 100 - pa;
        Jugador j = null;
        if (jugador == 'H') {
            j = new Huma(nom, pa, pd, Huma.getVidesInicials());
        }
        if (jugador == 'G') {
            j = new Guerrer(nom, pa, pd, Guerrer.getVidesInicials());
        }
        if (jugador == 'A') {
            j = new Alien(nom, pa, pd, Alien.getVidesInicials());
        }
        //Control d'errors per a no afegir a un jugador no existent
        if (!llista.contains(j)) {
            llista.add(j);
        }
    }

    private static void consultar() {
        //Bucle per a buscar a tots els jugadors
        for (int i = 0; i < llista.size(); i++) {
            System.out.println(llista);

        }
    }
    private static void eliminar() {
        //Pregunta el nom del jugador
        String nom = Teclat.lligString("Quin es el jugador que vols borrar?");
        //Crea un objecte que sera per a buscar al jugador
        Jugador jbus = new Jugador(nom, 0, 0, 0);
        //Control d'erros per a no borrar a un jugador no existent 
        if (llista.remove(jbus)) {
            System.out.println("Jugador borrat");
        } else {
            System.out.println("Eixe jugador no existeix");
        }
    }

    private static void assignarEquip() {
        //OBTINDRE JUG
        //preguntar nom jug
        String nomJugador = Teclat.lligString("Quin es el jugador que vols afegir al equip");
        //Crear jug a buscar
        Jugador jbusc = new Jugador(nomJugador, 0, 0, 0);
        //Obtindre la posicio 
        int posJug = llista.indexOf(jbusc);
        if (posJug < 0) {
            return;
        }
        //Obtindre jugReal
        Jugador jtrobat = llista.get(posJug);
        //OBTINDRE EQUIP
        //Preguntar nom d'equip
        String nomEquip = Teclat.lligString("Quin es el nom de l'equip?");
        //Crear eq a buscar
        Equip eqpbusc = new Equip(nomEquip);
        int posEq = llista.indexOf(eqpbusc);
        if (posEq < 0) {
            return;
        }
        Equip eqptrobat = Equips.llista.get(posEq);
        //Asignar Eq-Jug
        eqptrobat.posa(jtrobat);
    }

    private static void llevarEquip() {
        //OBTINDRE JUG
        //preguntar nom jug
        String nomJugador = Teclat.lligString("Quin es el jugador que vols afegir al equip");
        //Crear jug a buscar
        Jugador jbusc = new Jugador(nomJugador, 0, 0, 0);
        //Obtindre la posicio 
        int posJug = llista.indexOf(jbusc);
        if (posJug < 0) {
            return;
        }
        //Obtindre jugReal
        Jugador jtrobat = llista.get(posJug);
        //OBTINDRE EQUIP
        //Preguntar nom d'equip
        String nomEquip = Teclat.lligString("Quin es el nom de l'equip?");
        //Crear eq a buscar
        Equip eqpbusc = new Equip(nomEquip);
        int posEq = llista.indexOf(eqpbusc);
        if (posEq < 0) {
            return;
        }
        Equip eqptrobat = Equips.llista.get(posEq);
        //Asignar Eq-Jug
        eqptrobat.lleva(jtrobat);
    }

    private static void assignarPoder() {
        //Preguntar nom del jugador per a assignar-li el poder
        String nomJugador = Teclat.lligString("Quin es el jugador que vols afegir al equip");
        Jugador j = new Jugador(nomJugador, 0, 0, 0);
        //Control d'errors per a no assignar un poder a un jugador no existent
        if (!llista.contains(j)) {
            System.out.println("Eixe jugador no existeix");
            return;
        }
        //Preguntar per el nom, bonus de atac i de defensa
        String nom = Teclat.lligString("Quin es el nom del poder que vols afegir?");
        int pa = Teclat.lligInt("Quants punts d'atac te el poder?", 0);
        int pd = Teclat.lligInt("Quants punts de defensa te el poder?", 0);
        //Crear el poder
        Poder poder = new Poder(nom, pa, pd);
        //Afegeix el poder al jugador
        Poders.llista.add(poder);
    }
}
