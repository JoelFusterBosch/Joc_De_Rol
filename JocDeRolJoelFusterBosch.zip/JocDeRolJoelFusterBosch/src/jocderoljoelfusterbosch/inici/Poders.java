/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jocderoljoelfusterbosch.inici;

import Teclat.Teclat;
import altres.Poder;
import java.util.ArrayList;
/**
 *
 * @author Joel
 */
public class Poders {
    static ArrayList <Poder> llista= new ArrayList();
    static void menu() {
        boolean eixir_bucle = false;
        while (!eixir_bucle) {
            int opcio = Teclat.lligOpcio("PODERS", "Crear", "Consultar","Examinar");
            switch (opcio) {
                case 1:
                   crear();
                   break;
                case 2:
                   consultar();
                   break;
                case 3:
                   eliminar(); 
                   break;
                case 0:
                    eixir_bucle=true;
            }
        }
    }
        private static void crear() {
       //Pregunta el nom, bonus de poder i defensa per a afegir-lo
        String nom = Teclat.lligString("Quin nom vols per a l'equip?");
        int bonusAtc= Teclat.lligInt("Quin bonus de atac te?", 0, 10);
        int bonusDef= Teclat.lligInt("Quin bonus de atac te?", 0, 10);
        //Objecte poder per a afegir el poder
        Poder p = new Poder(nom,bonusAtc,bonusDef);
        //Controlador d'errors per a no posar 2 poders iguals
        if(!llista.contains(p)){
            llista.add(p);
        }
    }

    private static void consultar() {
        //Bucle per a buscar a tots els jugadors
        for (int i = 0; i < llista.size(); i++) {
            System.out.println(llista);   
        }
    }

    private static void eliminar() {
        //Pregunta pel nom i crea el poder a borrar
        String nom = Teclat.lligString("Quin es el jugador que vols borrar?");
        Poder jpodbus = new Poder(nom,0,0);
        if(llista.remove(jpodbus)){
            System.out.println("Poder borrat");
        }else{
            System.out.println("Eixe poder no existeix");
        }
    }
}
