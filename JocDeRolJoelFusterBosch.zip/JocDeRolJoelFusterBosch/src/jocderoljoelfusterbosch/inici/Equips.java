/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package jocderoljoelfusterbosch.inici;

import Teclat.Teclat;
import altres.Equip;
import java.util.ArrayList;

/**
 *
 * @author Joel
 */
public class Equips {
    static ArrayList <Equip> llista= new ArrayList();

    static void menu() {
            boolean eixir_bucle = false;
        while (!eixir_bucle) {
            int opcio = Teclat.lligOpcio("EQUIPS", "Crear", "Consultar","Eliminar");
            switch (opcio) {
                case 1:
                    crear();
                   break;
                case 2:
                   consultar();
                   break;
                case 3:
                   eliminar();
                   break;
                case 0:
                    eixir_bucle=true;
            }
        }
    }

    private static void crear() {
        //Pregunta pel nom de l'equip per a després afegir-lo
        String nom= Teclat.lligString("Quin es el nom del equip");
        Equip equip= new Equip(nom);
        llista.add(equip);
    }

    private static void consultar() {
        //Bucle per a buscar a tots els jugadors
        for (int i = 0; i < llista.size(); i++) {
            System.out.println(llista);    
        }
    }

    private static void eliminar() {
        //Demana el nom del jugador i crea l'objecte d'equip per a borrar el jugador de l'equip
        String nom = Teclat.lligString("Quin es el jugador que vols borrar?");
        Equip eqpbus = new Equip(nom);
        if(llista.remove(eqpbus)){
            System.out.println("Equip borrat");
        }else{
            System.out.println("Eixe equip no existeix");
        }
    }
}
