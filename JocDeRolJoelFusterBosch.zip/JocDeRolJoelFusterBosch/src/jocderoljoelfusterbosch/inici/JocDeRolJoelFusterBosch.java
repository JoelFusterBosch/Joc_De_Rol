/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package jocderoljoelfusterbosch.inici;

import Teclat.*;
import altres.Equip;
import altres.Poder;
import java.util.ArrayList;
import java.util.Random;
import jocderoljoelfusterbosch.personatges.Huma;
import jocderoljoelfusterbosch.personatges.Guerrer;
import jocderoljoelfusterbosch.personatges.Alien;
import jocderoljoelfusterbosch.personatges.Jugador;

/**
 *
 * @author Joel
 */
public class JocDeRolJoelFusterBosch {

    static void provaFase1() {
        //Creació de un huma
        String nomH = "";
        int paH = 6;
        int pdH = 4;
        int videsH = 10;
        Huma huma = new Huma(nomH, paH, pdH, videsH);
        System.out.println("Estic creant un huma");
        //Creació d'un alien
        String nomA = "";
        int paA = 8;
        int pdA = 4;
        int videsA = 9;
        Alien alien = new Alien(nomA, paA, pdA, videsA);
        System.out.println("Estic creant una alien");        
        //Creació d'un guerrer
        String nomG = "";
        int paG = 10;
        int pdG = 10;
        int videsG = 10;
        Guerrer guerrer = new Guerrer(nomG, paG, pdG, videsG);
        System.out.println("Estic creant un Guerrer");
    }

    private static void provaFase2() {
        //Creacio d'un guerrer
        String nomG = "Guerr";
        int paG = 10;
        int pdG = 10;
        int videsG = 10;
        Guerrer guerrer = new Guerrer(nomG, paG, pdG, videsG);
        //Creació d'un alien
        String nomA = "Ali";
        int paA = 8;
        int pdA = 4;
        int videsA = 9;
        Alien alien = new Alien(nomA, paA, pdA, videsA);
        //El guerrer ataca a l'alien
        guerrer.ataca(alien);
    }

    private static void provaFase3() {
        //Creació dun humà
        String nomH = "hu";
        int paH = 2;
        int pdH = 4;
        int videsH = 100000;
        Huma huma = new Huma(nomH, paH, pdH, videsH);
        System.out.println("Estic creant un huma");
        String nomA = "ali";
        int paA = 30;
        int pdA = 4;
        int videsA = 9;
        Alien alien = new Alien(nomA, paA, pdA, videsA);
        String nomG = "guerr";
        int paG = 30;
        int pdG = 10;
        int videsG = 50;
        System.out.println("Estic creant una alien");
        Guerrer guerrer = new Guerrer(nomG, paG, pdG, videsG);
        System.out.println("Estic creant un Guerrer");
        //Huma ataca a Guerrer
        huma.ataca(guerrer);
        //Alien ataca a Guerrer
        alien.ataca(guerrer);
    }

    private static void provaFase4() {
        //Creacio de 2 humans
        Huma j1 = new Huma("rjfioerf", 3, 4, 6);
        Huma j2 = new Huma("rjfifdf", 5, 74, 1);
        //Cracio de 2 equips
        Equip equip1 = new Equip("jio");
        Equip equip2 = new Equip("jio2");
        //Assignació dels jugadors dins del equips
        j1.setEquip(equip1);
        j2.setEquip(equip2);
        equip1.posa(j2);
        equip2.posa(j1);
        equip1.lleva(j2);
        equip2.posa(j2);
    }

    private static void provaFase5() {
        //Creació de 2 Humans
        Huma j1 = new Huma("rjfioerf", 3, 4, 6);
        Huma j2 = new Huma("rjfifdf", 5, 74, 1);
        //Creació de 2 Poders
        Poder p1 = new Poder("Raig laser", 25, 5);
        Poder p2 = new Poder("Pedum", 3, 0);
        //Lista de poders creada i posar els poders dins de la llista
        ArrayList<Poder> poders = new ArrayList();
        poders.add(p1);
        poders.add(p2);
        j1.setPoder(poders);
        j2.setPoder(poders);
        //Un jugador ataca a l'altre
        j1.ataca(j2);
    }

    private static void menuConfiguacio() {
        //Menu de configuracio de jugadors, equips i poders
        int opcio = Teclat.lligOpcio("CONFIGURACIO", "Jugadors", "Equips", "Poders");
        switch (opcio) {
            case 1:
                Jugadors.menu();
                break;
            case 2:
                Equips.menu();
                break;
            case 3:
                Poders.menu();
                break;
        }
    }

    public static void main(String[] args) {
        //Fase de prova
        boolean prova = Teclat.lligBoolean("Vols fer les fases de prova?");
        if (prova) {
            provaFase1();
            provaFase2();
            provaFase3();
            provaFase4();
            provaFase5();
        }
        //Bucle principal del joc per a configurar i jugar
        boolean eixir = false;
        while (!eixir) {
            //Menu de configuracio per a configurar jugadors, equips i podres i per a jugar
            int opcio = Teclat.lligOpcio("JOC DE ROL", "Configuracio", "Jugar");
            switch (opcio) {
                case 1:
                    menuConfiguacio();
                    break;
                case 2:
                    jugar();
                    break;
                case 0:
                    eixir = true;
                    System.out.println("Gracies per jugar :)");
                    break;
            }
        }
    }

    private static void jugar() {
        //Importar la llibreria: java.util.Random
        Random random = new Random();
        System.out.println("1.Automatitzat");
        System.out.println("2.Manual");
        //Pregunta al jugador si vol jugar de forma automàtica o de forma manual
        int opcio = Teclat.lligInt("Quin modo de joc vols 1/2", 1, 2);
        if (opcio == 1) {
            //Forma automàtica
            if (!Jugadors.llista.isEmpty()) {
                //Inicia es variables de posicionament 
                //i del jugador atacant i del jugador atacat
                int posJugAtac;
                Jugador jugAtacant;
                int posJugAtacat;
                Jugador jugAtacat;
                //Bucle on es desenvolupa la partida
                while (Jugadors.llista.size() != 1) {
                    //Dona valors aleatoris de jugadors per a que s'ataquem
                    posJugAtac = random.nextInt(0, Jugadors.llista.size());
                    jugAtacant = Jugadors.llista.get(posJugAtac);
                    posJugAtacat = random.nextInt(0, Jugadors.llista.size());
                    jugAtacat = Jugadors.llista.get(posJugAtacat);
                    //Control d'errors per a que no s'ataque a si mateix 
                    //(que el get no agarre el mateix index)
                    while (jugAtacant.equals(jugAtacat)) {
                        jugAtacat = Jugadors.llista.get(posJugAtacat);
                    }
                    jugAtacant.ataca(jugAtacat);
                    //Lleva als jugadors de la llista quan moren
                    if (jugAtacant.getVides() == 0) {
                        Jugadors.llista.remove(jugAtacant);
                    }
                    if (jugAtacat.getVides() == 0) {
                        Jugadors.llista.remove(jugAtacat);
                    }
                }
                //Mostra al jugador que ha guanyat la partida
                System.out.println("El guanyador es" + Jugadors.llista);
            }
            //Missatge de que no hi han jugadors
            System.out.println("Com penses jugar si no tens ningun jugador?");
        } else {
            //Bucle on es desenvolupa la partida
            if (!Jugadors.llista.isEmpty()) {
                while (Jugadors.llista.size() != 1) {
                    //Bucle per a recorrer als jugadors de forma ordenada
                    for (Jugador jugador : Jugadors.llista) {
                        //Diu el ttorn del jugador al qual li toca atacar
                        System.out.println("Torn de " + jugador);
                        //Pregunta el nom del jugador que va a ser atacat
                        String nomJug = Teclat.lligString("A qui vols atacar?");
                        Jugador jNom = new Jugador(nomJug, 0, 0, 0);
                        if (Jugadors.llista.contains(jNom)) {
                            //Jugador ataca a altre jugador
                            jugador.ataca(jNom);
                           
                        } else {
                            //Control d'errors per a no atacar a un jugador no existent
                            System.out.println("Eixe jugador no existeix, aixi que no pots atacar a algu que no existeix, a menys que vullgues pegar al aire :)");
                        }
                        //Lleva als jugadors de la llista quan moren
                        if (jugador.getVides() == 0) {
                            Jugadors.llista.remove(jugador);
                        }
                        if (jNom.getVides() == 0) {
                            Jugadors.llista.remove(jNom);
                        }
                    }
                }
                //Mostra al jugador que ha guanyat la partida
                System.out.println("El guanyador es" + Jugadors.llista);
            }
            //Missatge de que no hi han jugadors
            System.out.println("Com penses jugar si no tens ningun jugador?");
        }
    }
}
